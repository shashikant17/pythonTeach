import App from './App'
import './index.css'
import ReactDOM from 'react-dom'
ReactDOM.render(<App/>,document.querySelector("#root"))

