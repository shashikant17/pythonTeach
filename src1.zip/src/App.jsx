import React from 'react'
import Nav from './Navbar/Nav'
import Footer from './Footer/Footer'

function App() {
  return (
    <>
    <Nav/>
    <div className='container'>
      
    </div>
    <Footer/>
    </>
  )
}

export default App